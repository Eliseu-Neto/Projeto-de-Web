<?php

namespace Tests\Models;

use PHPUnit\Framework\TestCase;

class UserTest extends TestCase
{

    public function testUpdatePassword()
    {

    }
}
